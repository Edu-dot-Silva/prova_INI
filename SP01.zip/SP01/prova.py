import streamlit as st
from datetime import datetime
from ClassOPC import Coneccao_Opc
import base64
import time


st.set_page_config(page_title="Interface Máquina", layout="wide")

# Conexão com o OPC UA
conexao = Coneccao_Opc("opc.tcp://192.168.15.92:4840")
conexao.conectar_opc()

# Inicializando estados
if 'historico' not in st.session_state:
    st.session_state.historico = {
        "status": [],
        "data_hora": [],
        "tipo": []
    }

if 'tipo_garrafa' not in st.session_state:
    st.session_state.tipo_garrafa = 0
if 'maquina_ligada' not in st.session_state:
    st.session_state.maquina_ligada = False
if 'posicao' not in st.session_state:
    st.session_state.posicao = 0

# Tipos de garrafa
tipos = {
    0: ("PET", 'blue'),
    1: ("LATA", 'yellow'),
    2: ("RETORNÁVEL", 'green')
}

# Layout das colunas
col1, col2, col3 = st.columns([1, 2, 1])
with col1:
    st.image("logo_senai.png", width=200)
with col2:
    st.markdown("Sistema - Sucos")
with col3:
    st.markdown(f"{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")

st.divider()

# Adicionando colunas para os controles
col_tipo, col_botoes, col_status = st.columns([1, 1, 1])

# Seleção do tipo de garrafa
with col_tipo:
    st.markdown("Tipo de garrafa:")
    desabilitado = st.session_state.maquina_ligada

    if st.radio("Selecione o tipo de garrafa:", ["PET", "LATA", "RETORNÁVEL"], index=st.session_state.tipo_garrafa, disabled=desabilitado, key="selecao_radio") == "PET":
        st.session_state.tipo_garrafa = 0
    elif st.session_state.selecao_radio == "Lata":
        st.session_state.tipo_garrafa = 1
    else:
        st.session_state.tipo_garrafa = 2

    conexao.escrita_valor_inteiro("ns=4;s=|var|NEXTO PLC.Application.OPC_UA.TipoGarrafa", int(st.session_state.tipo_garrafa))

# Botões de controle
with col_botoes:
    st.markdown("Controle da máquina:")
    if st.button("Ligar", disabled=st.session_state.maquina_ligada):
        conexao.escrita_valor_booleano("ns=4;s=|var|NEXTO PLC.Application.OPC_UA.Liga", bool(True))
        st.session_state.maquina_ligada = True
        st.session_state.historico["status"].append("Ligado")
        st.session_state.historico["data_hora"].append(datetime.now().strftime('%d/%m/%Y %H:%M:%S'))
        st.session_state.historico["tipo"].append(tipos[st.session_state.tipo_garrafa][0])

    if st.button("Desligar", disabled=not st.session_state.maquina_ligada):
        conexao.escrita_valor_booleano("ns=4;s=|var|NEXTO PLC.Application.OPC_UA.Desliga", bool(False))
        st.session_state.maquina_ligada = False
        st.session_state.historico["status"].append("Desligado")
        st.session_state.historico["data_hora"].append(datetime.now().strftime('%d/%m/%Y %H:%M:%S'))
        st.session_state.historico["tipo"].append(tipos[st.session_state.tipo_garrafa][0])

# Indicador de status
with col_status:
    st.markdown("Status da máquina:")
    cor = "green" if st.session_state.maquina_ligada else "red"
    st.markdown(f"<div style='color: {cor};'>Máquina {'Ligada' if st.session_state.maquina_ligada else 'Desligada'}</div>", unsafe_allow_html=True)

st.divider()

# Animação da esteira
st.markdown("Simulação Esteira")

if st.session_state.maquina_ligada:
    pos = st.session_state.posicao
    _, cor = tipos[st.session_state.tipo_garrafa]
    blocos = ["⬛"] * 20
    blocos[pos] = "🟦"  # Quadrado azul representando a garrafa
    st.markdown("".join(blocos))
    st.session_state.posicao = (pos + 1) % 20
    time.sleep(0.1)
else:
    st.session_state.posicao = 0
    st.markdown("⬛" * 20)

st.divider()

# Histórico de operações
st.markdown("Histórico de operações")
for status, data_hora, tipo in zip(
    st.session_state.historico["status"],
    st.session_state.historico["data_hora"],
    st.session_state.historico["tipo"]
):
    st.markdown(f"- **{data_hora}** -> Máquina **{status}** com tipo **{tipo}**")

# Desconectar do OPC UA
conexao.desconectar_opc()
